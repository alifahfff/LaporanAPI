package com.example.longrunningapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LongRunningApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LongRunningApiApplication.class, args);
	}

}
