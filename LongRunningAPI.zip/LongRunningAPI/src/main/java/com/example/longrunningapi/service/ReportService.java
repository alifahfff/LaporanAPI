package com.example.longrunningapi.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

@Service
public class ReportService {

    @Async("taskExecutor")
    public CompletableFuture<InputStream> generateReport() {
        String data =
                        "WARUNG MAKMUR JAYA\n" +
                        "===========\n" +
                        "1. KOPI: 100 cup\n" +
                        "2. SUSU : 200 cup\n" +
                        "3. TEH : 400 cup\n" +
                        "4. STMJ : 50 cup\n" +
                        "5. WEDANG : 100 cup\n" +
                        "6. BAJIGUR : 250 cup\n" +
                        "7. SUSU JAHE : 50 cup\n"
                ;

        InputStream stream = new ByteArrayInputStream(data.getBytes(StandardCharsets.UTF_8));
        return CompletableFuture.completedFuture(stream);
    }
}