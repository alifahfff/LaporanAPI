package com.example.longrunningapi.controller;

import com.example.longrunningapi.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/download")
    public CompletableFuture<ResponseEntity<byte[]>> downloadReport() {
        return reportService.generateReport().thenApply(stream -> {
            try {
                byte[] data = stream.readAllBytes();
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
                headers.setContentDispositionFormData("attachment", "report.txt");

                return ResponseEntity.ok()
                        .headers(headers)
                        .body(data);
            } catch (Exception e) {
                return ResponseEntity.status(500).body(null);
            }
        });
    }
}