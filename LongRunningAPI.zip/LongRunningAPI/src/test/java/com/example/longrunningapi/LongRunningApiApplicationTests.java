package com.example.longrunningapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LongRunningApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
